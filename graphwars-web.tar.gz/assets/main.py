"""Graph Wars - Edición Profesorado de Matemática.

Juego educativo inspirado en Graphwar (graphwar.com): el jugador tiene una
nave en el origen del plano cartesiano y escribe funciones y(x) = f(x) para
destruir naves enemigas. El disparo se ajusta solo para salir siempre de la
propia nave, igual que el modo "Normal" del Graphwar original.

Un jugador: campaña de 3 niveles (naves fijas en el plano).
Batalla por turnos: hasta 4 jugadores se disparan entre sí, origen movible.
"""

import sys
import asyncio
import pygame

from levels_data import LEVELS
from level import Level
from battle import Battle, BattleSetup
from widgets import Button, TextBox

WIDTH, HEIGHT = 1100, 780
BG = (8, 10, 18)

PLANE_RECT = pygame.Rect(40, 46, WIDTH - 80, HEIGHT - 230)
PANEL_RECT = pygame.Rect(0, HEIGHT - 160, WIDTH, 160)


class App:
    def __init__(self, screen, fonts):
        self.screen = screen
        self.fonts = fonts
        self.state = 'menu'
        self.level_index = 0
        self.level = None
        self.total_shots = 0
        self.battle = None
        self.battle_setup = None
        self.player_name = 'Jugador 1'
        self.theme = 'dark'
        self.campaign_name_box = None
        self.campaign_level_buttons = []
        self._build_menu_buttons()

    def _build_menu_buttons(self):
        cx = WIDTH // 2
        self.menu_buttons = [
            Button((cx - 120, 300, 240, 55), 'Un jugador (Campaña)', self.show_campaign_setup),
            Button((cx - 120, 370, 240, 55), 'Batalla por turnos', self.show_battle_setup),
            Button((cx - 120, 440, 240, 55), 'Cómo jugar', self.show_instructions),
            Button((cx - 120, 510, 240, 55), '', self.toggle_theme),
            Button((cx - 120, 580, 240, 55), 'Salir', self.quit_game),
        ]
        self.theme_button = self.menu_buttons[3]

    def show_menu(self):
        self.state = 'menu'

    def toggle_theme(self):
        self.theme = 'light' if self.theme == 'dark' else 'dark'

    def show_instructions(self):
        self.state = 'instructions'

    def quit_game(self):
        pygame.quit()
        sys.exit()

    def start_level(self, idx):
        self.level_index = idx
        self.level = Level(LEVELS[idx], PLANE_RECT, PANEL_RECT,
                            player_name=self.player_name, theme=self.theme)
        self.state = 'level'

    def show_campaign_setup(self):
        cx = WIDTH // 2
        self.campaign_name_box = TextBox((cx - 160, 300, 320, 46), label='Nombre de tu personaje',
                                          numeric=False, max_len=16, initial=self.player_name)
        self.campaign_name_box.active = True
        self.campaign_level_buttons = [
            Button((cx - 200, 400 + i * 70, 400, 55), lvl['name'], (lambda i=i: self._start_campaign_level(i)))
            for i, lvl in enumerate(LEVELS)
        ]
        self.state = 'campaign_setup'

    def _start_campaign_level(self, idx):
        name = self.campaign_name_box.text.strip()
        self.player_name = name if name else 'Jugador 1'
        self.start_level(idx)

    def show_battle_setup(self):
        self.battle_setup = BattleSetup(pygame.Rect(0, 0, WIDTH, HEIGHT))
        self.battle_setup.start_button.callback = self.launch_battle
        self.state = 'battle_setup'

    def launch_battle(self):
        names = self.battle_setup.get_names()
        self.battle = Battle(names, PLANE_RECT, PANEL_RECT, theme=self.theme)
        self.state = 'battle'

    def _advance_after_level(self):
        self.total_shots += self.level.shots_fired
        if self.level_index + 1 < len(LEVELS):
            self.state = 'level_cleared'
        else:
            self.state = 'victory'

    # ----------------------------------------------------------------- input
    def handle_event(self, event):
        if event.type == pygame.QUIT:
            self.quit_game()

        if self.state == 'menu':
            for b in self.menu_buttons:
                b.handle_event(event)

        elif self.state == 'instructions':
            if event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
                self.show_menu()

        elif self.state == 'campaign_setup':
            self.campaign_name_box.handle_event(event)
            for b in self.campaign_level_buttons:
                b.handle_event(event)
            if event.type == pygame.KEYDOWN:
                if event.key == pygame.K_ESCAPE:
                    self.show_menu()
                elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                    self._start_campaign_level(0)

        elif self.state == 'level':
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                self.show_menu()
                return
            was_cleared = self.level.cleared
            self.level.handle_event(event)
            if self.level.cleared and not was_cleared:
                pass  # se avanza cuando el jugador confirma (ver más abajo)
            elif self.level.cleared and event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
                self._advance_after_level()

        elif self.state == 'level_cleared':
            if event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
                self.start_level(self.level_index + 1)

        elif self.state == 'victory':
            if event.type == pygame.MOUSEBUTTONDOWN:
                self.show_menu()

        elif self.state == 'battle_setup':
            self.battle_setup.handle_event(event)
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                self.show_menu()

        elif self.state == 'battle':
            if event.type == pygame.KEYDOWN and event.key == pygame.K_ESCAPE:
                self.show_menu()
                return
            self.battle.handle_event(event)

        elif self.state == 'battle_finished':
            if event.type in (pygame.KEYDOWN, pygame.MOUSEBUTTONDOWN):
                self.show_menu()

    def update(self, dt):
        if self.state == 'level' and self.level:
            self.level.update(dt)
        elif self.state == 'battle' and self.battle:
            self.battle.update(dt)
            if self.battle.phase == 'finished':
                self.state = 'battle_finished'

    # ------------------------------------------------------------------ draw
    def draw(self):
        self.screen.fill(BG)
        if self.state == 'menu':
            self._draw_menu()
        elif self.state == 'instructions':
            self._draw_instructions()
        elif self.state == 'campaign_setup':
            self._draw_campaign_setup()
        elif self.state == 'level':
            self.level.draw(self.screen, self.fonts)
        elif self.state == 'level_cleared':
            self._draw_level_cleared()
        elif self.state == 'victory':
            self._draw_victory()
        elif self.state == 'battle_setup':
            self.battle_setup.draw(self.screen, self.fonts)
        elif self.state == 'battle':
            self.battle.draw(self.screen, self.fonts)
        elif self.state == 'battle_finished':
            self._draw_battle_finished()
        pygame.display.flip()

    def _draw_menu(self):
        title = self.fonts['title'].render('GRAPH WARS', True, (90, 220, 255))
        self.screen.blit(title, title.get_rect(center=(WIDTH // 2, 140)))
        sub = self.fonts['sub'].render('Edición Profesorado de Matemática', True, (170, 190, 210))
        self.screen.blit(sub, sub.get_rect(center=(WIDTH // 2, 195)))
        self.theme_button.text = ('Tema: Claro' if self.theme == 'dark' else 'Tema: Oscuro')
        for b in self.menu_buttons:
            b.draw(self.screen, self.fonts['ui'])

    def _draw_instructions(self):
        lines = [
            ('CÓMO JUGAR', 'title'),
            ('', None),
            ('Tu nave está en el origen (0,0). Escribí y(x) = f(x): el disparo', 'sub'),
            ('sale siempre desde vos (se ajusta solo para pasar por tu nave).', 'sub'),
            ('Si el gráfico pasa por una nave enemiga, la destruye.', 'sub'),
            ('', None),
            ('Operadores: + - * / ^ o ** (potencia) y paréntesis.', 'sub'),
            ('Funciones: sqrt() log() ln() abs() sin() cos() tan() exp()', 'sub'),
            ('Ejemplos: 2x+3   x^2-4x+2   x**2+4   sin(x)*3   sqrt(x+5)', 'sub'),
            ('', None),
            ('Si un disparo no pasa por ninguna nave, no pasa nada: seguí probando.', 'sub'),
            ('¡Intentá acertarle a varias naves con un mismo disparo!', 'sub'),
            ('', None),
            ('ENTER o el botón Disparar: lanza la función.   ESC: volver al menú.', 'sub'),
            ('', None),
            ('Click o cualquier tecla para volver...', 'sub'),
        ]
        y = 70
        for text, kind in lines:
            if not text:
                y += 18
                continue
            font = self.fonts['title'] if kind == 'title' else self.fonts['sub']
            color = (90, 220, 255) if kind == 'title' else (210, 220, 235)
            txt = font.render(text, True, color)
            self.screen.blit(txt, txt.get_rect(center=(WIDTH // 2, y)))
            y += 42 if kind == 'title' else 30

    def _draw_campaign_setup(self):
        title = self.fonts['title'].render('UN JUGADOR', True, (90, 220, 255))
        self.screen.blit(title, title.get_rect(center=(WIDTH // 2, 140)))
        sub = self.fonts['sub'].render('Elegí el nombre de tu personaje:', True, (200, 220, 235))
        self.screen.blit(sub, sub.get_rect(center=(WIDTH // 2, 195)))
        self.campaign_name_box.draw(self.screen, self.fonts['ui'], self.fonts['label'])

        sub2 = self.fonts['sub'].render('Elegí el nivel:', True, (200, 220, 235))
        self.screen.blit(sub2, sub2.get_rect(center=(WIDTH // 2, 375)))
        for b in self.campaign_level_buttons:
            b.draw(self.screen, self.fonts['ui'])

        hint = self.fonts['small'].render('ESC: volver al menú   |   ENTER: empezar en el Nivel 1',
                                           True, (120, 130, 150))
        self.screen.blit(hint, hint.get_rect(
            center=(WIDTH // 2, self.campaign_level_buttons[-1].rect.bottom + 25)))

    def _draw_level_cleared(self):
        name = LEVELS[self.level_index]['name']
        title = self.fonts['title'].render('¡NIVEL SUPERADO!', True, (120, 255, 150))
        self.screen.blit(title, title.get_rect(center=(WIDTH // 2, 260)))
        sub = self.fonts['sub'].render(name, True, (200, 220, 235))
        self.screen.blit(sub, sub.get_rect(center=(WIDTH // 2, 320)))
        shots = self.fonts['sub'].render(
            f'Disparos usados: {self.level.shots_fired}', True, (170, 190, 210))
        self.screen.blit(shots, shots.get_rect(center=(WIDTH // 2, 360)))
        cont = self.fonts['sub'].render('Click o cualquier tecla para ir al siguiente nivel...',
                                         True, (150, 200, 255))
        self.screen.blit(cont, cont.get_rect(center=(WIDTH // 2, 430)))

    def _draw_victory(self):
        title = self.fonts['title'].render('¡COMPLETASTE GRAPH WARS!', True, (255, 210, 90))
        self.screen.blit(title, title.get_rect(center=(WIDTH // 2, 260)))
        shots = self.fonts['sub'].render(
            f'Disparos totales en los 3 niveles: {self.total_shots}', True, (200, 220, 235))
        self.screen.blit(shots, shots.get_rect(center=(WIDTH // 2, 330)))
        cont = self.fonts['sub'].render('Click para volver al menú principal...',
                                         True, (150, 200, 255))
        self.screen.blit(cont, cont.get_rect(center=(WIDTH // 2, 420)))

    def _draw_battle_finished(self):
        winner = self.battle.winner
        title = self.fonts['title'].render('¡BATALLA TERMINADA!', True, (255, 210, 90))
        self.screen.blit(title, title.get_rect(center=(WIDTH // 2, 260)))
        name = winner.name if winner else '???'
        color = winner.color if winner else (200, 220, 235)
        sub = self.fonts['sub'].render(f'Ganador: {name}', True, color)
        self.screen.blit(sub, sub.get_rect(center=(WIDTH // 2, 320)))
        shots = self.fonts['sub'].render(
            f'Disparos totales: {self.battle.shots_fired}', True, (200, 220, 235))
        self.screen.blit(shots, shots.get_rect(center=(WIDTH // 2, 360)))
        cont = self.fonts['sub'].render('Click o cualquier tecla para volver al menú...',
                                         True, (150, 200, 255))
        self.screen.blit(cont, cont.get_rect(center=(WIDTH // 2, 430)))


async def main():
    pygame.init()
    pygame.display.set_caption('Graph Wars - Edición Profesorado')
    screen = pygame.display.set_mode((WIDTH, HEIGHT))
    clock = pygame.time.Clock()

    # Versión web (pygbag/WASM): se usa la fuente por defecto de pygame
    # (siempre viene incluida) en vez de SysFont con 'arial'/'consolas',
    # porque en el navegador no hay fuentes del sistema operativo
    # disponibles para buscar por nombre.
    fonts = {
        'title': pygame.font.Font(None, 44),
        'sub': pygame.font.Font(None, 22),
        'ui': pygame.font.Font(None, 20),
        'label': pygame.font.Font(None, 18),
        'small': pygame.font.Font(None, 14),
    }
    fonts['title'].set_bold(True)
    fonts['label'].set_bold(True)

    app = App(screen, fonts)
    running = True
    while running:
        dt = clock.tick(60) / 1000.0
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                running = False
            else:
                app.handle_event(event)
        app.update(dt)
        app.draw()
        await asyncio.sleep(0)  # le cede el control al navegador cada frame

    pygame.quit()
    sys.exit()


if __name__ == '__main__':
    asyncio.run(main())
