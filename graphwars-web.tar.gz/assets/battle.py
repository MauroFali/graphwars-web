"""Modo Batalla: combate por turnos estilo Worms usando funciones matemáticas.

Hasta 4 jugadores, cada uno con su nave en el plano. En su turno, quien
dispara escribe una función y = f(x) tomando como origen (0, 0) la posición
de SU PROPIA nave: las posiciones de los rivales se muestran en coordenadas
relativas a quien dispara. La curva "viaja" de izquierda a derecha como un
proyectil; si pasa cerca de un rival, lo impacta (efecto de destrucción) y
ese rival queda eliminado. Tras cada disparo (impacte o no) pasa el turno,
hasta que sobreviva un solo jugador.
"""

import math
import random

import pygame

from plane import Plane
from parser import parse_function, FunctionParseError
from widgets import TextBox, Button

EXPLOSION_DURATION = 0.6
SWEEP_DURATION = 1.6
HIT_TOLERANCE = 0.5

PLAYER_COLORS = [
    (90, 200, 255),
    (255, 120, 130),
    (140, 255, 150),
    (255, 210, 90),
]


def _draw_helmet(surface, sx, sy):
    """Casco de soldado sobre la cabeza (sx, sy), dejando los ojos libres."""
    dome_color = (80, 100, 55)
    brim_color = (60, 78, 40)
    pygame.draw.ellipse(surface, brim_color, (sx - 15, sy - 11, 30, 7))
    pygame.draw.ellipse(surface, dome_color, (sx - 12, sy - 21, 24, 15))
    pygame.draw.ellipse(surface, (110, 130, 80), (sx - 6, sy - 19, 10, 5))


def _generate_positions(n):
    """Ubica a los n jugadores en un círculo alrededor del centro, con
    jitter, garantizando una separación mínima entre naves."""
    for _ in range(30):
        base_angle = random.uniform(0, 360)
        positions = []
        for i in range(n):
            angle = math.radians(base_angle + i * (360 / n) + random.uniform(-12, 12))
            radius = random.uniform(9.0, 14.0)
            x = round(radius * math.cos(angle))
            y = round(radius * math.sin(angle) * 0.55)
            positions.append((x, y))
        ok = True
        for i in range(len(positions)):
            for j in range(i + 1, len(positions)):
                dx = positions[i][0] - positions[j][0]
                dy = positions[i][1] - positions[j][1]
                if (dx * dx + dy * dy) ** 0.5 < 6:
                    ok = False
        if ok:
            return positions
    return positions


class Character:
    def __init__(self, name, bx, by, color):
        self.name = name
        self.bx = bx
        self.by = by
        self.color = color
        self.state = 'alive'  # alive -> exploding -> dead
        self.explosion_timer = 0.0

    def hit(self):
        if self.state == 'alive':
            self.state = 'exploding'
            self.explosion_timer = EXPLOSION_DURATION

    def update(self, dt):
        if self.state == 'exploding':
            self.explosion_timer -= dt
            if self.explosion_timer <= 0:
                self.state = 'dead'

    @property
    def out(self):
        return self.state != 'alive'


class BattleSetup:
    """Pantalla previa: elegir cantidad de jugadores (2 a 4) y sus nombres."""

    def __init__(self, area_rect):
        self.area = pygame.Rect(area_rect)
        self.count = 2
        cx = self.area.centerx
        self.count_buttons = [
            Button((cx - 165 + i * 110, self.area.y + 90, 90, 46), str(n), (lambda n=n: self.set_count(n)))
            for i, n in enumerate((2, 3, 4))
        ]
        self.name_boxes = [
            TextBox((cx - 160, self.area.y + 180 + i * 70, 320, 44),
                    label=f'Nombre jugador {i + 1}', numeric=False, max_len=16,
                    initial=f'Jugador {i + 1}')
            for i in range(4)
        ]
        self.name_boxes[0].active = True
        self.start_button = Button((cx - 110, self.area.y + 180 + 4 * 70 + 30, 220, 52),
                                    'Comenzar Batalla', callback=None)

    def set_count(self, n):
        if n < self.count:
            for i in range(n, self.count):
                self.name_boxes[i].active = False
        self.count = n
        if not any(self.name_boxes[i].active for i in range(self.count)):
            self.name_boxes[0].active = True

    def handle_event(self, event):
        for b in self.count_buttons:
            b.handle_event(event)
        for i in range(self.count):
            self.name_boxes[i].handle_event(event)
        self.start_button.handle_event(event)
        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_TAB:
                self._cycle_active()
            elif event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                if self.start_button.callback:
                    self.start_button.callback()

    def _cycle_active(self):
        actives = [i for i in range(self.count) if self.name_boxes[i].active]
        for i in range(self.count):
            self.name_boxes[i].active = False
        nxt = (actives[0] + 1) % self.count if actives else 0
        self.name_boxes[nxt].active = True

    def get_names(self):
        names = []
        for i in range(self.count):
            t = self.name_boxes[i].text.strip()
            names.append(t if t else f'Jugador {i + 1}')
        return names

    def draw(self, surface, fonts):
        title = fonts['title'].render('BATALLA POR TURNOS', True, (90, 220, 255))
        surface.blit(title, title.get_rect(center=(self.area.centerx, self.area.y + 20)))
        sub = fonts['sub'].render('Elegí la cantidad de jugadores:', True, (200, 220, 235))
        surface.blit(sub, sub.get_rect(center=(self.area.centerx, self.area.y + 65)))

        for btn, n in zip(self.count_buttons, (2, 3, 4)):
            selected = (n == self.count)
            color = (70, 165, 230) if selected else (35, 60, 85)
            pygame.draw.rect(surface, color, btn.rect, border_radius=8)
            pygame.draw.rect(surface, (20, 24, 34), btn.rect, 2, border_radius=8)
            txt = fonts['ui'].render(btn.text, True, (255, 255, 255))
            surface.blit(txt, txt.get_rect(center=btn.rect.center))

        for i in range(self.count):
            color = PLAYER_COLORS[i % len(PLAYER_COLORS)]
            box = self.name_boxes[i]
            pygame.draw.circle(surface, color, (box.rect.x - 22, box.rect.centery), 8)
            self.name_boxes[i].draw(surface, fonts['ui'], fonts['label'])

        self.start_button.draw(surface, fonts['ui'])

        hint = fonts['small'].render('ESC: volver al menú   |   ENTER: comenzar', True, (120, 130, 150))
        surface.blit(hint, hint.get_rect(center=(self.area.centerx, self.start_button.rect.bottom + 30)))


class Battle:
    def __init__(self, names, plane_rect, panel_rect, theme='dark'):
        self.plane = Plane(plane_rect, theme=theme)
        self.panel_rect = pygame.Rect(panel_rect)
        positions = _generate_positions(len(names))
        self.players = [
            Character(name, bx, by, PLAYER_COLORS[i % len(PLAYER_COLORS)])
            for i, (name, (bx, by)) in enumerate(zip(names, positions))
        ]
        self.current = random.randrange(len(self.players))
        self.phase = 'aiming'  # aiming -> firing -> resolving -> finished
        self.projectile = None
        self.shots_fired = 0
        self.message = ''
        self.message_is_error = False
        self.message_timer = 0.0
        self.winner = None
        self._build_input()
        self._set_message(f'¡{self.shooter.name} empieza la batalla!', False)

    def _build_input(self):
        box_w = 420
        x = self.panel_rect.x + 40
        y = self.panel_rect.y + 55
        self.input_box = TextBox((x, y, box_w, 42), label='y(x) =', numeric=False, max_len=60)
        self.input_box.active = True
        self.fire_button = Button((x + box_w + 22, y, 150, 42), 'Disparar', callback=self.fire)

    @property
    def shooter(self):
        return self.players[self.current]

    # ----------------------------------------------------------------- logic
    def fire(self):
        if self.phase != 'aiming':
            return
        shooter = self.shooter
        try:
            raw_f = parse_function(self.input_box.text)
        except FunctionParseError as e:
            self._set_message(str(e), True)
            return

        try:
            origin_val = raw_f(0)
        except Exception:
            origin_val = None
        if not isinstance(origin_val, (int, float)) or origin_val != origin_val:
            self._set_message('Tu función no está definida en tu propia posición. Probá otra.', True)
            return

        # El disparo sale siempre de tu nave (x=0): se desplaza verticalmente
        # la función escrita para que pase exactamente por vos.
        shift = -origin_val

        def f(x):
            v = raw_f(x)
            return None if v is None else v + shift

        candidates = []
        for other in self.players:
            if other is shooter or other.out:
                continue
            trx = other.bx - shooter.bx
            tr_y = other.by - shooter.by
            try:
                val = f(trx)
            except Exception:
                val = None
            if isinstance(val, (int, float)) and val == val and abs(val - tr_y) <= HIT_TOLERANCE:
                candidates.append((trx, other))

        # El proyectil sale de la nave (x=0) y avanza por igual hacia ambos
        # lados, así que el primero en alcanzarse es el de menor |x|.
        hit_x, hit_target = (None, None)
        if candidates:
            hit_x, hit_target = min(candidates, key=lambda c: abs(c[0]))

        samples = self.plane.sample_raw(f)
        x0, x1 = self.plane.x_min, self.plane.x_max
        half_domain = max(abs(x0), abs(x1)) or 1.0
        if hit_target is not None:
            frac = abs(hit_x) / half_domain
            frac = max(0.08, min(1.0, frac))
        else:
            frac = 1.0
        duration = max(0.35, SWEEP_DURATION * frac)

        self.projectile = {
            'samples': samples,
            'duration': duration,
            'age': 0.0,
            'hit_target': hit_target,
            'color': shooter.color,
        }
        self.phase = 'firing'
        self.shots_fired += 1
        self.input_box.text = ''
        self.message = ''

    def _set_message(self, text, error):
        self.message = text
        self.message_is_error = error
        self.message_timer = 3.0 if error else 1.8

    def _segments_within_reach(self, samples, reach):
        """Reconstruye los segmentos ya recorridos por el proyectil: la
        ventana [-reach, +reach] alrededor de la nave que disparó (x=0)."""
        segments = []
        current = []
        for wx, wy in samples:
            in_window = -reach <= wx <= reach
            if wy is None or not in_window:
                if len(current) >= 2:
                    segments.append(current)
                current = []
                continue
            current.append(self.plane.to_screen(wx, wy))
        if len(current) >= 2:
            segments.append(current)
        return segments

    def _end_turn(self):
        self.projectile = None
        alive = [p for p in self.players if not p.out]
        if len(alive) <= 1:
            self.phase = 'finished'
            self.winner = alive[0] if alive else None
            return
        n = len(self.players)
        nxt = self.current
        for _ in range(n):
            nxt = (nxt + 1) % n
            if not self.players[nxt].out:
                break
        self.current = nxt
        self.phase = 'aiming'
        self.input_box.active = True
        self._set_message(f'Turno de {self.shooter.name}', False)

    # ---------------------------------------------------------------- events
    def handle_event(self, event):
        if self.phase != 'aiming':
            return
        self.input_box.handle_event(event)
        self.fire_button.handle_event(event)
        if event.type == pygame.KEYDOWN and event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
            self.fire()

    # ---------------------------------------------------------------- update
    def update(self, dt):
        for p in self.players:
            p.update(dt)

        if self.message_timer > 0:
            self.message_timer -= dt
            if self.message_timer <= 0 and self.phase == 'aiming':
                self.message = ''

        if self.phase == 'firing' and self.projectile:
            proj = self.projectile
            proj['age'] += dt
            if proj['age'] >= proj['duration']:
                proj['age'] = proj['duration']
                if proj['hit_target'] is not None:
                    proj['hit_target'].hit()
                    self._set_message(f'¡{self.shooter.name} impactó a {proj["hit_target"].name}!', False)
                else:
                    self._set_message('Sin impactos... pasa el turno.', False)
                self.phase = 'resolving'

        elif self.phase == 'resolving':
            target = self.projectile['hit_target'] if self.projectile else None
            if target is None or target.state == 'dead':
                self._end_turn()

    # ------------------------------------------------------------------ draw
    def _draw_ship(self, surface, p, sx, sy, fonts, is_shooter):
        if p.state == 'exploding':
            frac = 1 - (p.explosion_timer / EXPLOSION_DURATION)
            radius = max(1, int(14 + frac * 26))
            alpha = max(0, 255 - int(frac * 255))
            expl = pygame.Surface((80, 80), pygame.SRCALPHA)
            pygame.draw.circle(expl, (255, 200, 60, alpha), (40, 40), radius, 3)
            pygame.draw.circle(expl, (255, 120, 40, alpha), (40, 40), max(2, int(radius * 0.6)), 2)
            surface.blit(expl, (sx - 40, sy - 40))
            return
        ring_w = 3 if is_shooter else 2
        pygame.draw.circle(surface, p.color, (sx, sy), 13)
        pygame.draw.circle(surface, (255, 255, 255) if is_shooter else (20, 20, 30), (sx, sy), 13, ring_w)
        _draw_helmet(surface, sx, sy)
        pygame.draw.circle(surface, (20, 20, 30), (sx - 4, sy - 3), 2)
        pygame.draw.circle(surface, (20, 20, 30), (sx + 4, sy - 3), 2)
        name_txt = fonts['small'].render(p.name, True, self.plane.axis_color)
        surface.blit(name_txt, name_txt.get_rect(center=(sx, sy - 32)))

    def draw(self, surface, fonts):
        pygame.draw.rect(surface, self.plane.bg_color, self.plane.rect)
        self.plane.draw_grid(surface, fonts['small'])

        shooter = self.shooter

        overlay = pygame.Surface((self.plane.rect.width, self.plane.rect.height), pygame.SRCALPHA)
        if self.projectile:
            proj = self.projectile
            frac = proj['age'] / proj['duration'] if proj['duration'] else 1.0
            x0, x1 = self.plane.x_min, self.plane.x_max
            half_domain = max(abs(x0), abs(x1)) or 1.0
            reach = half_domain * min(1.0, frac)
            segs = self._segments_within_reach(proj['samples'], reach)
            col = (*proj['color'], 255)
            for seg in segs:
                local = [(px - self.plane.rect.x, py - self.plane.rect.y) for px, py in seg]
                pygame.draw.lines(overlay, col, False, local, 3)

            if self.phase == 'firing':
                pos_tip, neg_tip = None, None
                for wx, wy in proj['samples']:
                    if wy is None:
                        continue
                    if 0 <= wx <= reach:
                        pos_tip = (wx, wy)
                    if -reach <= wx <= 0 and neg_tip is None:
                        neg_tip = (wx, wy)
                for tip in (pos_tip, neg_tip):
                    if tip is None:
                        continue
                    tx, ty = self.plane.to_screen(*tip)
                    pygame.draw.circle(overlay, (255, 255, 255, 255),
                                        (tx - self.plane.rect.x, ty - self.plane.rect.y), 5)
        surface.blit(overlay, self.plane.rect.topleft)

        for p in self.players:
            if p.state == 'dead':
                continue
            rx, ry = p.bx - shooter.bx, p.by - shooter.by
            sx, sy = self.plane.to_screen(rx, ry)
            self._draw_ship(surface, p, sx, sy, fonts, is_shooter=(p is shooter))

        turn_txt = fonts['label'].render(f'Turno de: {shooter.name}', True, shooter.color)
        surface.blit(turn_txt, (self.plane.rect.x, 6))

        alive_txt = fonts['ui'].render(
            f'Jugadores en pie: {sum(1 for p in self.players if not p.out)}/{len(self.players)}   '
            f'Disparos: {self.shots_fired}', True, (170, 200, 230))
        surface.blit(alive_txt, (self.plane.rect.right - alive_txt.get_width(), 6))

        hint = fonts['small'].render(
            'El origen (0,0) es tu nave: las posiciones de los rivales son relativas a vos.',
            True, (140, 220, 180))
        surface.blit(hint, (self.plane.rect.x, self.plane.rect.bottom + 4))

        pygame.draw.rect(surface, (16, 20, 32), self.panel_rect)
        pygame.draw.line(surface, (50, 60, 80), self.panel_rect.topleft, self.panel_rect.topright, 2)
        self.input_box.draw(surface, fonts['ui'], fonts['label'])
        self.fire_button.draw(surface, fonts['ui'])

        esc_hint = fonts['small'].render('ESC: menú   |   ENTER: disparar', True, (120, 130, 150))
        surface.blit(esc_hint, (self.panel_rect.right - esc_hint.get_width() - 20,
                                 self.panel_rect.bottom - 24))

        if self.message:
            color = (255, 120, 120) if self.message_is_error else (150, 230, 255)
            msg_txt = fonts['ui'].render(self.message, True, color)
            surface.blit(msg_txt, (self.panel_rect.x + 20, self.panel_rect.y + 12))
