"""Lógica de un nivel: nave del jugador, naves objetivo, entrada de
funciones, disparos animados y colisiones."""

import math

import pygame

from plane import Plane
from parser import parse_function, FunctionParseError
from widgets import TextBox, Button

EXPLOSION_DURATION = 0.5
SWEEP_DURATION = 1.4
VERTICAL_LEAD_DURATION = 0.5  # cuánto tarda en dibujarse la línea punteada hacia (0, c)
PLAYER_COLOR = (90, 200, 255)


def _draw_dashed_line(surface, color, p0, p1, dash_len=7, gap_len=6, width=3):
    """Línea punteada de p0 a p1 (en coordenadas de pantalla)."""
    x0, y0 = p0
    x1, y1 = p1
    dist = math.hypot(x1 - x0, y1 - y0)
    if dist < 1e-6:
        return
    ux, uy = (x1 - x0) / dist, (y1 - y0) / dist
    pos = 0.0
    drawing = True
    while pos < dist:
        step = dash_len if drawing else gap_len
        end = min(pos + step, dist)
        if drawing:
            a = (x0 + ux * pos, y0 + uy * pos)
            b = (x0 + ux * end, y0 + uy * end)
            pygame.draw.line(surface, color, a, b, width)
        pos = end
        drawing = not drawing


def _segment_hits_circle(p1, p2, cx, cy, r):
    """¿El segmento p1-p2 (en coordenadas del mundo) pasa a <= r de (cx,cy)?
    Se usa para chocar contra piedras: mirar el segmento entero (no solo
    los dos extremos) evita que una curva "se cuele" entre dos muestras."""
    x1, y1 = p1
    x2, y2 = p2
    dx, dy = x2 - x1, y2 - y1
    length2 = dx * dx + dy * dy
    if length2 < 1e-12:
        t = 0.0
    else:
        t = ((cx - x1) * dx + (cy - y1) * dy) / length2
        t = max(0.0, min(1.0, t))
    nx, ny = x1 + t * dx, y1 + t * dy
    return (nx - cx) ** 2 + (ny - cy) ** 2 <= r * r


def _draw_helmet(surface, sx, sy):
    """Casco de soldado sobre la cabeza (sx, sy), dejando los ojos libres."""
    dome_color = (80, 100, 55)
    brim_color = (60, 78, 40)
    pygame.draw.ellipse(surface, brim_color, (sx - 15, sy - 11, 30, 7))
    pygame.draw.ellipse(surface, dome_color, (sx - 12, sy - 21, 24, 15))
    pygame.draw.ellipse(surface, (110, 130, 80), (sx - 6, sy - 19, 10, 5))


class Target:
    def __init__(self, x, y):
        self.x = x
        self.y = y
        self.state = 'alive'  # alive -> exploding -> destroyed
        self.explosion_timer = 0.0

    def hit(self):
        if self.state == 'alive':
            self.state = 'exploding'
            self.explosion_timer = EXPLOSION_DURATION

    def update(self, dt):
        if self.state == 'exploding':
            self.explosion_timer -= dt
            if self.explosion_timer <= 0:
                self.state = 'destroyed'


class Player:
    def __init__(self, name, x, y):
        self.name = name
        self.x = x
        self.y = y
        self.color = PLAYER_COLOR


class Projectile:
    """Anima el trazo de la curva viajando desde la nave del jugador, e
    impacta a cada nave enemiga cuando el trazo la alcanza.

    'direction' es 'both' (función completa), 'right' o 'left' (solo esa
    mitad). En 'both' el disparo va primero a la IZQUIERDA por completo
    (sin borrarse) y recién después a la DERECHA; todo el trazo se
    desvanece junto recién cuando termina de dibujarse del todo."""

    def __init__(self, samples, player_x, hit_list, hit_any, direction='both',
                 left_extent=0.0, right_extent=0.0, vertical_lead=None):
        self.samples = samples
        self.player_x = player_x
        self.hit_list = hit_list  # [{'dist':, 'target':, 'side':, 'applied': False}, ...]
        self.hit_any = hit_any
        self.direction = direction
        self.left_extent = left_extent
        self.right_extent = right_extent
        self.half_domain = left_extent if direction == 'left' else right_extent
        self.duration = SWEEP_DURATION if direction != 'both' else SWEEP_DURATION * 2
        self.age = 0.0
        self.done = False
        self.fade_age = 0.0
        self.ttl = 1.5  # tiempo que el trazo queda visible antes de borrarse

        # Tramo previo opcional: una línea punteada vertical desde la nave
        # hasta (x, y_to) -que puede ser el "c" real, o antes, si una
        # piedra la frena-. El tramo horizontal (arriba) no arranca a
        # avanzar hasta que este tramo termine.
        self.vertical_lead = vertical_lead  # {'x','y_from','y_to','duration'} o None
        self._v_age = 0.0
        self.vertical_done = vertical_lead is None

    def reach(self):
        """Alcance para direction 'left' o 'right' (un solo sentido)."""
        frac = min(1.0, self.age / self.duration) if self.duration else 1.0
        return self.half_domain * frac

    def reach_left(self):
        if self.direction != 'both':
            return self.reach() if self.direction == 'left' else 0.0
        half_dur = self.duration / 2
        frac = min(1.0, self.age / half_dur) if half_dur else 1.0
        return self.left_extent * frac

    def reach_right(self):
        if self.direction != 'both':
            return self.reach() if self.direction == 'right' else 0.0
        half_dur = self.duration / 2
        if self.age <= half_dur:
            return 0.0
        frac = min(1.0, (self.age - half_dur) / half_dur) if half_dur else 1.0
        return self.right_extent * frac

    def update(self, dt):
        if not self.vertical_done:
            self._v_age += dt
            if self._v_age >= self.vertical_lead['duration']:
                self.vertical_done = True
                if self.half_domain_total() <= 1e-9:
                    # Nada para recorrer horizontalmente (p.ej. la piedra
                    # frenó la línea punteada antes de llegar a "c"):
                    # el disparo termina ahí mismo.
                    self.done = True
            return  # el tramo horizontal espera a que termine el vertical

        if not self.done:
            self.age += dt
            if self.direction == 'both':
                rl, rr = self.reach_left(), self.reach_right()
                for entry in self.hit_list:
                    if entry['applied']:
                        continue
                    reach = rl if entry['side'] == 'left' else rr
                    if entry['dist'] <= reach:
                        entry['target'].hit()
                        entry['applied'] = True
            else:
                reach = self.reach()
                for entry in self.hit_list:
                    if not entry['applied'] and entry['dist'] <= reach:
                        entry['target'].hit()
                        entry['applied'] = True
            if self.age >= self.duration:
                self.done = True
        else:
            self.fade_age += dt

    def half_domain_total(self):
        return self.left_extent + self.right_extent if self.direction == 'both' else self.half_domain

    def vertical_progress(self):
        if self.vertical_lead is None:
            return 1.0
        dur = self.vertical_lead['duration']
        return min(1.0, self._v_age / dur) if dur else 1.0

    def vertical_point(self):
        """(x, y) de la punta de la línea punteada en este instante."""
        vl = self.vertical_lead
        frac = self.vertical_progress()
        y = vl['y_from'] + (vl['y_to'] - vl['y_from']) * frac
        return vl['x'], y

    def alpha(self):
        if not self.done:
            return 255
        return max(0, int(255 * (1 - self.fade_age / self.ttl)))

    def expired(self):
        return self.done and self.fade_age >= self.ttl


class Level:
    def __init__(self, data, plane_rect, panel_rect, player_name='Jugador 1', theme='dark'):
        self.data = data
        self.plane = Plane(plane_rect, theme=theme)
        self.panel_rect = pygame.Rect(panel_rect)
        self.targets = [Target(x, y) for x, y in data['targets']]
        self.obstacles = data.get('obstacles', [])  # [(x, y, radio), ...]
        # Por defecto el disparo se desplaza para salir siempre de tu nave
        # (no importa "c"). Si un nivel pone shift_to_player=False (como el
        # Nivel 2), se dispara la función literal a·x²+b·x+c: "c" pasa a
        # ser de verdad el punto de partida en el eje Y.
        self.shift_to_player = data.get('shift_to_player', True)
        self.player = Player(player_name, 0, 0)
        self.selected_target = None  # nave clickeada: se le muestra la coordenada
        self.shots = []
        self.shots_fired = 0
        self.message = ''
        self.message_is_error = False
        self.message_timer = 0.0
        self.cleared = False
        self.input_mode = data.get('input_mode', 'free')
        self.coeff_terms = data.get('coeff_terms', [])
        self.preview_pos = None
        self.boxes = {}
        self.fire_button = None
        self.full_function = True
        self.full_function_button = None
        self.shot_direction = 'right'
        self.direction_button = None
        self._build_inputs()

    # ---------------------------------------------------------------- inputs
    def _build_inputs(self):
        box_h, gap = 42, 22
        x = self.panel_rect.x + 40
        y = self.panel_rect.y + 55
        self.boxes = {}

        if self.input_mode == 'coeffs':
            # Una caja numérica chica por cada coeficiente (a, b, c, ...) y,
            # al lado, el espacio donde se dibuja la vista previa en vivo
            # de y(x). Los botones quedan en una segunda fila.
            coeff_w, coeff_gap = 64, 16
            for term in self.coeff_terms:
                self.boxes[term['name']] = TextBox((x, y, coeff_w, box_h), label=term['label'],
                                                    numeric=True, max_len=8)
                x += coeff_w + coeff_gap
            self.preview_pos = (x + 20, y)
            btn_x = self.panel_rect.x + 40
            row_y = y + box_h + 16
        else:
            wide_w = 360
            self.boxes['expr'] = TextBox((x, y, wide_w, box_h), label='y(x) =', numeric=False, max_len=60)
            btn_x = x + wide_w + gap
            row_y = y

        self.fire_button = Button((btn_x, row_y, 150, box_h), 'Disparar', callback=self.fire)
        self.full_function_button = Button((btn_x + 150 + gap, row_y, 230, box_h), '',
                                            callback=self._toggle_full_function)
        self.direction_button = Button((btn_x + 150 + gap + 230 + gap, row_y, 200, box_h), '',
                                        callback=self._toggle_direction)
        next(iter(self.boxes.values())).active = True

    def _coeff_preview_text(self):
        """Texto 'y(x) = ...' armado en vivo con lo que hay en las cajas de
        coeficientes, usando placeholders (a, b, c) donde todavía no se
        escribió un número válido."""
        parts = []
        first = True
        for term in self.coeff_terms:
            name = term['name']
            power = term['power']
            suffix = {2: 'x²', 1: 'x', 0: ''}.get(power, f'x^{power}')
            raw = self.boxes[name].text.strip()
            val = None
            if raw not in ('', '-', '.', '-.', '+'):
                try:
                    val = float(raw)
                except ValueError:
                    val = None
            if val is None:
                body = f'{name}{suffix}'
                parts.append(body if first else f'+ {body}')
                first = False
                continue
            if val == 0 and suffix:
                continue  # coeficiente 0 en un término con x: no se muestra
            sign = '-' if val < 0 else '+'
            mag = abs(val)
            mag_s = str(int(mag)) if mag == int(mag) else str(mag)
            coef_s = '' if (suffix and mag == 1) else mag_s
            body = f'{coef_s}{suffix}'
            parts.append((f'-{body}' if sign == '-' else body) if first else f'{sign} {body}')
            first = False
        if not parts:
            parts = ['0']
        return 'y(x) = ' + ' '.join(parts)

    def _build_raw_function(self):
        """Devuelve f(x) a partir de la entrada del jugador, o None si hubo
        un error (y ya se seteó el mensaje correspondiente)."""
        if self.input_mode == 'coeffs':
            values = {}
            for term in self.coeff_terms:
                name = term['name']
                raw = self.boxes[name].text.strip()
                if raw in ('', '-', '.', '-.', '+'):
                    self._set_message('Completá los valores de a, b y c.', error=True)
                    return None
                try:
                    values[name] = float(raw)
                except ValueError:
                    self._set_message(f"El valor de '{name}' no es un número válido.", error=True)
                    return None
            terms = self.coeff_terms

            def raw_f(x):
                return sum(values[t['name']] * (x ** t['power']) for t in terms)
            return raw_f

        try:
            return parse_function(self.boxes['expr'].text)
        except FunctionParseError as e:
            self._set_message(str(e), error=True)
            return None

    def _blocked_extent(self, samples, px):
        """Mira la curva ya calculada (samples) y, para cada lado del
        jugador, devuelve la distancia a la piedra más cercana que la curva
        toca (None si ese lado está libre de piedras).

        Chequea el SEGMENTO entre cada par de puntos consecutivos (no solo
        los puntos sueltos): si solo se mirara punto por punto, una curva
        que cruza una piedra "de paso" entre dos muestras podría no tocar
        ningún punto exacto y colarse sin chocar."""
        block_left, block_right = None, None
        prev = None
        for wx, wy in samples:
            cur = None if wy is None else (wx, wy)
            if prev is not None and cur is not None:
                for ox, oy, orad in self.obstacles:
                    if _segment_hits_circle(prev, cur, ox, oy, orad):
                        dist = abs(wx - px)
                        if wx < px:
                            if block_left is None or dist < block_left:
                                block_left = dist
                        else:
                            if block_right is None or dist < block_right:
                                block_right = dist
                        break
            prev = cur
        return block_left, block_right

    def _blocked_vertical(self, px, y_from, y_to):
        """Si hay una piedra sobre la línea vertical x=px entre y_from e
        y_to, devuelve la altura (la más cercana a y_from) donde la línea
        punteada se frena. None si ese tramo está libre."""
        lo, hi = (y_from, y_to) if y_to >= y_from else (y_to, y_from)
        best = None
        for ox, oy, orad in self.obstacles:
            dx = px - ox
            if abs(dx) > orad:
                continue  # la piedra ni toca esa vertical
            half = math.sqrt(orad ** 2 - dx ** 2)
            enter, exit_ = max(lo, oy - half), min(hi, oy + half)
            if enter > exit_:
                continue  # el tramo [y_from, y_to] no llega a cruzar la piedra
            # el borde de la piedra más cercano a donde arrancamos (y_from)
            cand = enter if y_to >= y_from else exit_
            if best is None or abs(cand - y_from) < abs(best - y_from):
                best = cand
        return best

    def _toggle_full_function(self):
        self.full_function = not self.full_function

    def _toggle_direction(self):
        self.shot_direction = 'left' if self.shot_direction == 'right' else 'right'

    # ----------------------------------------------------------------- logic
    def fire(self):
        if self.cleared:
            return
        raw_f = self._build_raw_function()
        if raw_f is None:
            return  # ya se seteó el mensaje de error

        px, py = self.player.x, self.player.y
        try:
            origin_val = raw_f(px)
        except Exception:
            origin_val = None
        if not isinstance(origin_val, (int, float)) or origin_val != origin_val:
            self._set_message('Tu función no está definida en tu propia posición. Probá otra.', error=True)
            return

        vertical_lead = None
        vertical_blocked = False
        if self.shift_to_player:
            # El disparo sale siempre de tu nave: se desplaza verticalmente
            # la función escrita para que pase exactamente por tu posición
            # ("c" se cancela, no importa dónde digas que arranca).
            shift = py - origin_val

            def f(x):
                v = raw_f(x)
                return None if v is None else v + shift
        else:
            # La función se dispara literal: "c" (origin_val) es de verdad
            # el punto de partida en el eje Y. Primero se dibuja, punteada,
            # la línea de tu nave hasta ahí; si una piedra la frena antes,
            # el disparo ni llega a empezar la curva.
            f = raw_f
            c_val = origin_val
            v_block = self._blocked_vertical(px, py, c_val) if self.obstacles else None
            vertical_blocked = v_block is not None
            vertical_lead = {
                'x': px, 'y_from': py,
                'y_to': v_block if vertical_blocked else c_val,
                'duration': VERTICAL_LEAD_DURATION,
                'blocked': vertical_blocked,
            }

        left_extent = abs(px - self.plane.x_min) or 1.0
        right_extent = abs(self.plane.x_max - px) or 1.0

        samples = self.plane.sample_raw(f)

        if vertical_blocked:
            # Nunca se llega a dibujar la curva: no hay nada que alcance
            # ninguna nave en este disparo.
            left_extent = right_extent = 0.0
        elif self.obstacles:
            # Si hay piedras en el camino, el disparo choca y no sigue de
            # largo: se recorta el alcance de cada lado a la distancia de
            # la piedra más cercana que la curva toca.
            block_left, block_right = self._blocked_extent(samples, px)
            if block_left is not None:
                left_extent = min(left_extent, block_left)
            if block_right is not None:
                right_extent = min(right_extent, block_right)

        if self.full_function:
            direction = 'both'
        else:
            # Solo se dibuja (y puede impactar) el lado elegido con el
            # botón de dirección.
            direction = self.shot_direction

        tol = self.data.get('tolerance', 0.35)
        hit_list = []
        blocked_hit = False
        for t in self.targets:
            if t.state != 'alive':
                continue
            side = 'left' if t.x < px else 'right'
            if direction == 'right' and side == 'left':
                continue
            if direction == 'left' and side == 'right':
                continue
            try:
                val = f(t.x)
            except Exception:
                val = None
            if not (isinstance(val, (int, float)) and val == val and abs(val - t.y) <= tol):
                continue
            allowed = left_extent if side == 'left' else right_extent
            if abs(t.x - px) > allowed:
                blocked_hit = True  # la curva pasaba por la nave, pero una piedra la frenó antes
                continue
            hit_list.append({'dist': abs(t.x - px), 'target': t, 'side': side, 'applied': False})

        hit_any = bool(hit_list)

        self.shots.append(Projectile(samples, px, hit_list, hit_any, direction,
                                      left_extent, right_extent, vertical_lead=vertical_lead))
        self.shots_fired += 1

        if hit_any:
            self._set_message('¡Impacto!', error=False)
        elif vertical_blocked:
            self._set_message('¡Una piedra te frenó en el eje Y! Probá otro valor de c.', error=True)
        elif blocked_hit:
            self._set_message('¡Chocaste con una piedra! Probá una curva que la esquive.', error=True)
        else:
            self._set_message('Sin impactos... probá otra función.', error=False)

    def _set_message(self, text, error):
        self.message = text
        self.message_is_error = error
        self.message_timer = 3.0 if error else 1.4

    # ---------------------------------------------------------------- events
    def handle_event(self, event):
        for box in self.boxes.values():
            box.handle_event(event)
        self.fire_button.handle_event(event)
        self.full_function_button.handle_event(event)
        if not self.full_function:
            self.direction_button.handle_event(event)

        if event.type == pygame.KEYDOWN:
            if event.key in (pygame.K_RETURN, pygame.K_KP_ENTER):
                self.fire()
            elif event.key == pygame.K_TAB:
                self._cycle_active()
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1 and not self.cleared:
            self._handle_target_click(event.pos)

    def _handle_target_click(self, pos):
        """Click sobre una nave (viva o estallando): muestra su coordenada
        (x, y). Click de nuevo sobre la misma nave, o en cualquier otro
        lado, la oculta."""
        clicked = None
        for t in self.targets:
            if t.state == 'destroyed':
                continue
            sx, sy = self.plane.to_screen(t.x, t.y)
            if (pos[0] - sx) ** 2 + (pos[1] - sy) ** 2 <= 18 ** 2:
                clicked = t
                break
        self.selected_target = None if clicked is self.selected_target else clicked

    def _cycle_active(self):
        keys = list(self.boxes.keys())
        actives = [i for i, k in enumerate(keys) if self.boxes[k].active]
        for k in keys:
            self.boxes[k].active = False
        nxt = (actives[0] + 1) % len(keys) if actives else 0
        self.boxes[keys[nxt]].active = True

    # ---------------------------------------------------------------- update
    def update(self, dt):
        for s in self.shots:
            s.update(dt)
        self.shots = [s for s in self.shots if not s.expired()]
        for t in self.targets:
            t.update(dt)
        if self.message_timer > 0:
            self.message_timer -= dt
            if self.message_timer <= 0:
                self.message = ''
        if not self.cleared and self.targets and all(t.state != 'alive' for t in self.targets):
            self.cleared = True
            self.message = ''

    # ------------------------------------------------------------------ draw
    def _segments_within_reach(self, samples, center_x, reach_left, reach_right):
        segments = []
        current = []
        for wx, wy in samples:
            in_window = (center_x - reach_left) <= wx <= (center_x + reach_right)
            if wy is None or not in_window:
                if len(current) >= 2:
                    segments.append(current)
                current = []
                continue
            current.append(self.plane.to_screen(wx, wy))
        if len(current) >= 2:
            segments.append(current)
        return segments

    def _draw_player(self, surface, fonts):
        sx, sy = self.plane.to_screen(self.player.x, self.player.y)
        pygame.draw.circle(surface, self.player.color, (sx, sy), 13)
        pygame.draw.circle(surface, self.plane.outline_color, (sx, sy), 13, 3)
        _draw_helmet(surface, sx, sy)
        pygame.draw.circle(surface, (20, 20, 30), (sx - 4, sy - 3), 2)
        pygame.draw.circle(surface, (20, 20, 30), (sx + 4, sy - 3), 2)
        name_txt = fonts['small'].render(self.player.name, True, self.plane.axis_color)
        surface.blit(name_txt, name_txt.get_rect(center=(sx, sy + 22)))

    @staticmethod
    def _fmt_num(v):
        if abs(v - round(v)) < 1e-6:
            return str(int(round(v)))
        return f'{v:.2f}'.rstrip('0').rstrip('.')

    def _draw_coord_label(self, surface, fonts, t):
        """Cartel con la coordenada (x, y) de la nave clickeada."""
        sx, sy = self.plane.to_screen(t.x, t.y)
        label = f'({self._fmt_num(t.x)}, {self._fmt_num(t.y)})'
        txt = fonts['small'].render(label, True, (30, 24, 10))
        pad_x, pad_y = 8, 5
        box_w, box_h = txt.get_width() + 2 * pad_x, txt.get_height() + 2 * pad_y
        bx = min(max(sx - box_w // 2, self.plane.rect.left), self.plane.rect.right - box_w)
        by = sy - 24 - box_h
        if by < self.plane.rect.top:
            by = sy + 24  # si no entra arriba de la nave, se pone abajo
        box = pygame.Surface((box_w, box_h), pygame.SRCALPHA)
        pygame.draw.rect(box, (255, 225, 120, 235), box.get_rect(), border_radius=5)
        pygame.draw.rect(box, (140, 100, 20, 255), box.get_rect(), 2, border_radius=5)
        box.blit(txt, (pad_x, pad_y))
        surface.blit(box, (bx, by))

    def _draw_target(self, surface, t):
        if t.state == 'destroyed':
            return
        sx, sy = self.plane.to_screen(t.x, t.y)
        if t.state == 'alive':
            pygame.draw.circle(surface, (230, 70, 90), (sx, sy), 12)
            pygame.draw.circle(surface, (255, 210, 90), (sx, sy), 12, 2)
            _draw_helmet(surface, sx, sy)
            pygame.draw.circle(surface, (20, 20, 30), (sx - 4, sy - 3), 2)
            pygame.draw.circle(surface, (20, 20, 30), (sx + 4, sy - 3), 2)
        else:  # exploding
            frac = 1 - (t.explosion_timer / EXPLOSION_DURATION)
            radius = max(1, int(12 + frac * 22))
            alpha = max(0, 255 - int(frac * 255))
            expl = pygame.Surface((70, 70), pygame.SRCALPHA)
            pygame.draw.circle(expl, (255, 200, 60, alpha), (35, 35), radius, 3)
            pygame.draw.circle(expl, (255, 120, 40, alpha), (35, 35), max(2, int(radius * 0.6)), 2)
            surface.blit(expl, (sx - 35, sy - 35))

    def _draw_obstacle(self, surface, ox, oy, orad):
        """Piedra: forma irregular, para que no se confunda con una nave
        (son círculos chicos y rojos). El radio de dibujo es el radio REAL
        de colisión (en píxeles) -ni un poco más-: si se dibujara más
        grande que el real, la curva podría "tocar" la piedra dibujada sin
        chocar de verdad, y parecería que la pasa de largo sin motivo."""
        sx, sy = self.plane.to_screen(ox, oy)
        r = max(6, int(round(orad * self.plane.scale)))
        rock_color = (130, 118, 104)
        dark_color = (75, 66, 56)
        highlight = (165, 155, 138)
        offsets = [(0.0, -1.0), (0.55, -0.75), (0.95, -0.1), (0.7, 0.65),
                   (0.1, 1.0), (-0.6, 0.8), (-1.0, 0.15), (-0.75, -0.55)]
        points = [(sx + dx * r, sy + dy * r) for dx, dy in offsets]
        pygame.draw.polygon(surface, rock_color, points)
        pygame.draw.polygon(surface, dark_color, points, 3)
        pygame.draw.circle(surface, highlight, (sx - r // 4, sy - r // 3), max(2, r // 6))
        pygame.draw.circle(surface, dark_color, (sx + r // 4, sy + r // 4), max(2, r // 5))

    def draw(self, surface, fonts):
        pygame.draw.rect(surface, self.plane.bg_color, self.plane.rect)
        self.plane.draw_grid(surface, fonts['small'])

        for ox, oy, orad in self.obstacles:
            self._draw_obstacle(surface, ox, oy, orad)

        overlay = pygame.Surface((self.plane.rect.width, self.plane.rect.height), pygame.SRCALPHA)
        for shot in self.shots:
            if shot.vertical_lead is not None:
                vl = shot.vertical_lead
                p0 = self.plane.to_screen(vl['x'], vl['y_from'])
                p1 = self.plane.to_screen(*shot.vertical_point())
                vcolor = (230, 90, 90) if vl['blocked'] else (150, 210, 255)
                local0 = (p0[0] - self.plane.rect.x, p0[1] - self.plane.rect.y)
                local1 = (p1[0] - self.plane.rect.x, p1[1] - self.plane.rect.y)
                _draw_dashed_line(overlay, (*vcolor, shot.alpha()), local0, local1)
                if not shot.vertical_done:
                    continue  # todavía no hay nada horizontal para dibujar
            if shot.direction == 'both':
                rl, rr = shot.reach_left(), shot.reach_right()
                growing_left = (not shot.done) and shot.age <= shot.duration / 2
                growing_right = (not shot.done) and shot.age > shot.duration / 2
            elif shot.direction == 'right':
                rl, rr = 0.0, (shot.reach() if not shot.done else shot.half_domain)
                growing_left, growing_right = False, not shot.done
            else:
                rl, rr = (shot.reach() if not shot.done else shot.half_domain), 0.0
                growing_left, growing_right = not shot.done, False

            segs = self._segments_within_reach(shot.samples, shot.player_x, rl, rr)
            color = (60, 230, 130) if shot.hit_any else (230, 90, 90)
            col = (*color, shot.alpha())
            for seg in segs:
                local = [(px - self.plane.rect.x, py - self.plane.rect.y) for px, py in seg]
                pygame.draw.lines(overlay, col, False, local, 3)

            pos_tip, neg_tip = None, None
            for wx, wy in shot.samples:
                if wy is None:
                    continue
                if growing_right and shot.player_x <= wx <= shot.player_x + rr:
                    pos_tip = (wx, wy)
                if growing_left and shot.player_x - rl <= wx <= shot.player_x and neg_tip is None:
                    neg_tip = (wx, wy)
            for tip in (pos_tip, neg_tip):
                if tip is None:
                    continue
                tx, ty = self.plane.to_screen(*tip)
                pygame.draw.circle(overlay, (255, 255, 255, 255),
                                    (tx - self.plane.rect.x, ty - self.plane.rect.y), 5)
        surface.blit(overlay, self.plane.rect.topleft)

        self._draw_player(surface, fonts)

        for t in self.targets:
            self._draw_target(surface, t)

        if self.selected_target is not None and self.selected_target.state != 'destroyed':
            self._draw_coord_label(surface, fonts, self.selected_target)

        name_txt = fonts['label'].render(self.data['name'], True, (230, 240, 255))
        surface.blit(name_txt, (self.plane.rect.x, 6))

        remaining = sum(1 for t in self.targets if t.state == 'alive')
        stats_txt = fonts['ui'].render(
            f'Naves restantes: {remaining}/{len(self.targets)}   Disparos: {self.shots_fired}',
            True, (170, 200, 230))
        surface.blit(stats_txt, (self.plane.rect.right - stats_txt.get_width(), 6))

        hint = fonts['small'].render(self.data['formula_hint'], True, (140, 220, 180))
        surface.blit(hint, (self.plane.rect.x, self.plane.rect.bottom + 4))

        pygame.draw.rect(surface, (16, 20, 32), self.panel_rect)
        pygame.draw.line(surface, (50, 60, 80), self.panel_rect.topleft, self.panel_rect.topright, 2)
        for box in self.boxes.values():
            box.draw(surface, fonts['ui'], fonts['label'])

        if self.input_mode == 'coeffs' and self.preview_pos:
            preview = fonts['ui'].render(self._coeff_preview_text(), True, (150, 230, 255))
            px_, py_ = self.preview_pos
            any_box = next(iter(self.boxes.values()))
            surface.blit(preview, (px_, py_ + (any_box.rect.height - preview.get_height()) // 2))

        self.fire_button.draw(surface, fonts['ui'])

        self.full_function_button.text = ('Función completa: ON' if self.full_function
                                           else 'Función completa: OFF')
        self.full_function_button.color = (45, 130, 80) if self.full_function else (90, 60, 40)
        self.full_function_button.hover = (60, 165, 100) if self.full_function else (120, 85, 55)
        self.full_function_button.draw(surface, fonts['ui'])

        if not self.full_function:
            self.direction_button.text = ('Derecha ►' if self.shot_direction == 'right'
                                           else '◄ Izquierda')
            self.direction_button.color = (45, 130, 200)
            self.direction_button.hover = (70, 165, 230)
            self.direction_button.draw(surface, fonts['ui'])
            sub_hint = fonts['small'].render('Elegí hacia dónde dispara la función', True, (200, 170, 130))
            surface.blit(sub_hint, (self.full_function_button.rect.x, self.full_function_button.rect.y - 20))

        esc_hint = fonts['small'].render('ESC: menú   |   ENTER: disparar   |   TAB: siguiente campo',
                                          True, (120, 130, 150))
        surface.blit(esc_hint, (self.panel_rect.right - esc_hint.get_width() - 20,
                                 self.panel_rect.bottom - 24))

        if self.message:
            color = (255, 120, 120) if self.message_is_error else (150, 230, 255)
            msg_txt = fonts['ui'].render(self.message, True, color)
            surface.blit(msg_txt, (self.panel_rect.x + 20, self.panel_rect.y + 12))

        if self.cleared:
            box = pygame.Surface((520, 70), pygame.SRCALPHA)
            pygame.draw.rect(box, (10, 30, 20, 210), box.get_rect(), border_radius=10)
            pygame.draw.rect(box, (90, 230, 140, 255), box.get_rect(), 2, border_radius=10)
            txt = fonts['label'].render('¡NIVEL SUPERADO! (click o tecla para continuar)', True, (150, 255, 180))
            box.blit(txt, txt.get_rect(center=(260, 35)))
            surface.blit(box, box.get_rect(center=(self.plane.rect.centerx, self.plane.rect.centery)))
