"""Widgets simples de UI para pygame: cuadros de texto y botones."""

import pygame


class TextBox:
    def __init__(self, rect, label='', numeric=False, max_len=12, initial=''):
        self.rect = pygame.Rect(rect)
        self.label = label
        self.numeric = numeric
        self.max_len = max_len
        self.text = initial
        self.active = False

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN:
            self.active = self.rect.collidepoint(event.pos)
        elif event.type == pygame.KEYDOWN and self.active:
            if event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            # Enter/Tab: el estado (Level) decide qué hacer con ellos.
            # El resto de las teclas NO se procesa acá: se usa el evento
            # TEXTINPUT (más abajo), porque es el único que compone bien
            # teclas muertas de layouts en español/latino (por ejemplo "^",
            # que en esos teclados requiere tecla muerta + otra tecla).
        elif event.type == pygame.TEXTINPUT and self.active:
            for ch in event.text:
                if len(self.text) >= self.max_len:
                    break
                if self.numeric:
                    if ch in '0123456789.-':
                        self.text += ch
                else:
                    if ch.isprintable():
                        self.text += ch

    def draw(self, surface, font, label_font):
        border = (90, 220, 255) if self.active else (90, 100, 120)
        pygame.draw.rect(surface, (20, 26, 40), self.rect, border_radius=6)
        pygame.draw.rect(surface, border, self.rect, 2, border_radius=6)
        if self.label:
            lbl = label_font.render(self.label, True, (170, 185, 210))
            surface.blit(lbl, (self.rect.x, self.rect.y - 20))
        txt = font.render(self.text, True, (230, 240, 255))
        surface.blit(txt, (self.rect.x + 8, self.rect.y + (self.rect.height - txt.get_height()) // 2))
        if self.active and (pygame.time.get_ticks() // 500) % 2 == 0:
            cx = self.rect.x + 10 + txt.get_width()
            cy1 = self.rect.y + 6
            cy2 = self.rect.y + self.rect.height - 6
            pygame.draw.line(surface, (230, 240, 255), (cx, cy1), (cx, cy2), 2)


class Button:
    def __init__(self, rect, text, callback=None, color=(45, 130, 200), hover=(70, 165, 230)):
        self.rect = pygame.Rect(rect)
        self.text = text
        self.callback = callback
        self.color = color
        self.hover = hover

    def draw(self, surface, font):
        mouse = pygame.mouse.get_pos()
        c = self.hover if self.rect.collidepoint(mouse) else self.color
        pygame.draw.rect(surface, c, self.rect, border_radius=8)
        pygame.draw.rect(surface, (20, 24, 34), self.rect, 2, border_radius=8)
        txt = font.render(self.text, True, (255, 255, 255))
        surface.blit(txt, txt.get_rect(center=self.rect.center))

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                if self.callback:
                    self.callback()
                return True
        return False
