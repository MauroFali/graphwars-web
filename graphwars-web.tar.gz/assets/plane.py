"""Plano cartesiano: transforma coordenadas del mundo (x, y) a píxeles de pantalla
y dibuja la grilla, los ejes y las curvas de las funciones."""

import pygame

THEMES = {
    'dark': {
        'bg': (10, 14, 24),
        'grid': (32, 42, 62),
        'axis': (255, 255, 255),
        'label': (125, 145, 170),
        'outline': (255, 255, 255),
    },
    'light': {
        'bg': (255, 255, 255),
        'grid': (210, 215, 225),
        'axis': (20, 24, 34),
        'label': (90, 100, 120),
        'outline': (20, 24, 34),
    },
}


class Plane:
    def __init__(self, rect, x_range=(-25, 25), y_range=(-15, 15), theme='dark'):
        self.rect = pygame.Rect(rect)
        self.x_min, self.x_max = x_range
        self.y_min, self.y_max = y_range
        self.scale = min(
            self.rect.width / (self.x_max - self.x_min),
            self.rect.height / (self.y_max - self.y_min),
        )
        self.origin = (
            self.rect.left + self.rect.width / 2,
            self.rect.top + self.rect.height / 2,
        )
        self.set_theme(theme)

    def set_theme(self, theme):
        self.theme = theme if theme in THEMES else 'dark'
        colors = THEMES[self.theme]
        self.bg_color = colors['bg']
        self.grid_color = colors['grid']
        self.axis_color = colors['axis']
        self.label_color = colors['label']
        self.outline_color = colors['outline']

    def to_screen(self, x, y):
        sx = self.origin[0] + x * self.scale
        sy = self.origin[1] - y * self.scale
        return sx, sy

    def draw_grid(self, surface, font):
        grid_color = self.grid_color
        axis_color = self.axis_color
        label_color = self.label_color

        # Con rangos grandes, etiquetar cada línea satura de texto: se
        # separan las etiquetas más que las líneas finas de la grilla.
        label_step = 5 if (self.x_max - self.x_min) > 30 else 2

        for gx in range(int(self.x_min), int(self.x_max) + 1):
            sx, _ = self.to_screen(gx, 0)
            pygame.draw.line(surface, grid_color, (sx, self.rect.top), (sx, self.rect.bottom))
        for gy in range(int(self.y_min), int(self.y_max) + 1):
            _, sy = self.to_screen(0, gy)
            pygame.draw.line(surface, grid_color, (self.rect.left, sy), (self.rect.right, sy))

        ox, oy = self.to_screen(0, 0)
        pygame.draw.line(surface, axis_color, (self.rect.left, oy), (self.rect.right, oy), 2)
        pygame.draw.line(surface, axis_color, (ox, self.rect.top), (ox, self.rect.bottom), 2)

        for gx in range(int(self.x_min), int(self.x_max) + 1, label_step):
            if gx == 0:
                continue
            sx, _ = self.to_screen(gx, 0)
            lbl = font.render(str(gx), True, label_color)
            surface.blit(lbl, (sx - lbl.get_width() / 2, oy + 4))
        for gy in range(int(self.y_min), int(self.y_max) + 1, label_step):
            if gy == 0:
                continue
            _, sy = self.to_screen(0, gy)
            lbl = font.render(str(gy), True, label_color)
            surface.blit(lbl, (ox + 6, sy - lbl.get_height() / 2))

    def sample_raw(self, f, samples=500):
        """Devuelve una lista de (x_mundo, y_mundo_o_None) evaluando f(x) en
        todo el rango visible del plano. Se usa para animar un proyectil y
        para reconstruir sus segmentos de pantalla en cualquier tramo."""
        pts = []
        for i in range(samples + 1):
            wx = self.x_min + (self.x_max - self.x_min) * i / samples
            try:
                wy = f(wx)
            except Exception:
                wy = None
            valid = isinstance(wy, (int, float)) and wy == wy
            if valid and (wy < self.y_min - 6 or wy > self.y_max + 6):
                valid = False
            pts.append((wx, wy if valid else None))
        return pts
