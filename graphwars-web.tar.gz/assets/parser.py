"""Parseo seguro de expresiones matemáticas y = f(x) escritas por el estudiante.

Se permiten: la variable x, números, + - * / ^ (potencia), paréntesis, y las
funciones sqrt(), log(), ln(), abs(), sin(), cos(), tan(), exp().
No se usa eval() sobre texto crudo: se recorre el árbol sintáctico (ast) de
forma recursiva y se rechaza cualquier nodo que no sea aritmética o una de
esas funciones permitidas, así no se puede colar código arbitrario en el
cuadro de texto.
"""

import ast
import math
import re

ALLOWED_FUNCS = {
    'sqrt': math.sqrt,
    'log': math.log10,
    'ln': math.log,
    'abs': abs,
    'sin': math.sin,
    'cos': math.cos,
    'tan': math.tan,
    'exp': math.exp,
}

ALLOWED_BINOPS = (ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.Mod)
ALLOWED_UNARYOPS = (ast.USub, ast.UAdd)


class FunctionParseError(Exception):
    """Se lanza cuando el estudiante escribió algo que no se puede interpretar."""


def _preprocess(expr):
    expr = expr.strip()
    if not expr:
        raise FunctionParseError("Ingresá una expresión para y = f(x).")

    expr = expr.replace(',', '.').replace('^', '**').replace('X', 'x')
    expr = re.sub(r'\s+', '', expr)

    # Multiplicación implícita: "2x" -> "2*x", "3(x+1)" -> "3*(x+1)", etc.
    expr = re.sub(r'(?<=[0-9\)])(?=x)', '*', expr)
    expr = re.sub(r'(?<=x)(?=[0-9\(])', '*', expr)
    expr = re.sub(r'(?<=[0-9])(?=\()', '*', expr)
    expr = re.sub(r'(?<=\))(?=[0-9x\(])', '*', expr)
    return expr


def _validate(node):
    """Recorre el árbol y levanta FunctionParseError ante cualquier nodo que
    no sea aritmética simple sobre 'x' o una llamada a ALLOWED_FUNCS."""
    if isinstance(node, ast.Expression):
        _validate(node.body)
    elif isinstance(node, ast.BinOp):
        if not isinstance(node.op, ALLOWED_BINOPS):
            raise FunctionParseError("Solo se permiten +, -, *, /, ^ (potencia) y paréntesis.")
        _validate(node.left)
        _validate(node.right)
    elif isinstance(node, ast.UnaryOp):
        if not isinstance(node.op, ALLOWED_UNARYOPS):
            raise FunctionParseError("Operador no permitido.")
        _validate(node.operand)
    elif isinstance(node, ast.Call):
        func_name = node.func.id if isinstance(node.func, ast.Name) else None
        if func_name not in ALLOWED_FUNCS:
            nice = ', '.join(sorted(ALLOWED_FUNCS))
            raise FunctionParseError(f"Función no permitida (usá: {nice}).")
        if node.keywords or len(node.args) != 1:
            raise FunctionParseError(f"{func_name}(...) necesita exactamente un argumento.")
        _validate(node.args[0])
    elif isinstance(node, ast.Constant):
        if not isinstance(node.value, (int, float)):
            raise FunctionParseError("Solo se permiten números.")
    elif isinstance(node, ast.Name):
        if node.id != 'x':
            raise FunctionParseError(f"Solo se permite la variable 'x' (encontré '{node.id}').")
    else:
        raise FunctionParseError("Solo se permiten +, -, *, /, ^ (potencia), paréntesis y funciones.")


def parse_function(expr_str):
    """Devuelve una función f(x) a partir del texto escrito por el estudiante."""
    processed = _preprocess(expr_str)

    try:
        tree = ast.parse(processed, mode='eval')
    except SyntaxError:
        raise FunctionParseError(f'No entendí la expresión: "{expr_str}"')

    _validate(tree)

    code = compile(tree, '<expr>', 'eval')
    safe_names = dict(ALLOWED_FUNCS)

    def f(x_val):
        try:
            return eval(code, {'__builtins__': {}}, {'x': x_val, **safe_names})
        except (ZeroDivisionError, OverflowError, ValueError, TypeError):
            return None

    try:
        test = f(1.0)
    except Exception:
        raise FunctionParseError(f'No pude evaluar la expresión: "{expr_str}"')
    if test is not None and not isinstance(test, (int, float)):
        raise FunctionParseError("La expresión no da como resultado un número.")

    return f
