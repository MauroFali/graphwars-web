"""Configuración de los tres niveles del juego.

Los Niveles 1 y 3 usan el cuadro de texto libre "y(x) =": el estudiante
escribe la expresión completa (por ejemplo "2x+3" o "x^2-4x+2") y el juego
evalúa si el gráfico pasa por cada nave. Ahí, cada disparo se desplaza
verticalmente para salir siempre de la nave del jugador (fija en el origen
(0,0)): la trayectoria real de lo que se escribe como "f(x)" es
"f(x) - f(0)", así que solo importa la FORMA de la función (pendiente,
curvatura), no su ordenada al origen ("shift_to_player": True, el default).

El Nivel 2 es distinto ("shift_to_player": False): usa cajas separadas
para a, b y c (ver "input_mode": "coeffs" más abajo) y la función SÍ se
dispara literal, sin desplazamiento, así que "c" importa de verdad (ver el
comentario dentro de ese nivel).

tolerance: margen de error (en unidades del plano) para considerar que la
curva "pasó" por una nave.
"""

LEVELS = [
    {
        # Los 5 enemigos están, cada uno, sobre una recta y=m*x que pasa
        # exactamente por el origen (la nave del jugador):
        #   y=x      -> mata a (7, 7)
        #   y=(1/2)x -> mata a (-10, -5)
        #   y=3x     -> mata a (-4, -12)
        #   y=-5x    -> mata a (2, -10)
        #   y=2x     -> mata a (6, 12)
        'name': 'Nivel 1: Enemigos desde el origen',
        'formula_hint': 'Escribí y(x) = m·x, una recta que pasa por el origen. Ej: 3x',
        'targets': [(7, 7), (-10, -5), (-4, -12), (2, -10), (6, 12)],
        'tolerance': 0.4,
    },
    {
        # A diferencia de los otros niveles, ACÁ la función se dispara
        # literal (shift_to_player=False): no se desplaza para "cancelar"
        # c, así que c es de verdad el punto donde arranca la curva sobre
        # el eje Y (y(0)=c). Por eso el disparo tiene dos tramos: primero
        # una línea punteada (animada, igual de lenta que el disparo) que
        # va de tu nave hasta (0, c); recién de ahí sale la parábola hacia
        # los costados. NO hay piedras sobre el eje Y a propósito: todas
        # las naves comparten ese mismo eje, así que una piedra puesta ahí
        # bloquearía a cualquiera que necesite pasar por esa altura, no
        # solo a la "trampa" de alguien en particular.
        #
        # Las piedras sí bloquean el tramo horizontal: cada una está puesta
        # sobre la única recta a=0 (misma c, pendiente b) que también
        # llegaría a esa nave -la "trampa" de pensar que no hace falta
        # curvar-. Las 4 posiciones y radios salieron de una búsqueda
        # numérica (no a ojo) que garantiza, para las 4 parábolas a la vez:
        # que ninguna piedra toca el eje Y, que cada piedra deja pasar con
        # margen de sobra a SU PROPIA parábola, y que ninguna piedra queda
        # demasiado cerca del camino real de las otras 3 naves:
        #   Nave 1 (3, 13):   y=x^2+4         (a=1,b=0,c=4)    trampa y=3x+4
        #   Nave 2 (-3,-13):  y=-x^2-4        (a=-1,b=0,c=-4)  trampa y=3x-4
        #   Nave 3 (4, -10):  y=-0.5x^2-2     (a=-0.5,b=0,c=-2) trampa y=-2x-2
        #   Nave 4 (-4, 8):   y=0.5x^2+0.5x+2 (a=0.5,b=0.5,c=2) trampa y=-1.5x+2
        'name': 'Nivel 2: Funciones Cuadráticas',
        'formula_hint': 'Completá a, b y c. La punteada te muestra dónde arrancás (c); las piedras frenan la recta, no la parábola.',
        'targets': [(3, 13), (-3, -13), (4, -10), (-4, 8)],
        'tolerance': 0.4,
        'shift_to_player': False,
        # Modo de entrada por coeficientes (en vez del cuadro de texto
        # libre): se completan los valores de a, b y c de y = a·x^2+b·x+c
        # y al lado se ve en vivo cómo queda armada la función.
        'input_mode': 'coeffs',
        'coeff_terms': [
            {'name': 'a', 'power': 2, 'label': 'a'},
            {'name': 'b', 'power': 1, 'label': 'b'},
            {'name': 'c', 'power': 0, 'label': 'c'},
        ],
        'obstacles': [
            (0.63, 5.89, 0.50),    # Nave 1: frena la recta y=3x+4
            (-1.75, -9.24, 0.40),  # Nave 2: frena la recta y=3x-4
            (0.71, -3.42, 0.59),   # Nave 3: frena la recta y=-2x-2
            (-2.95, 6.43, 0.40),   # Nave 4: frena la recta y=-1.5x+2
        ],
    },
    {
        'name': 'Nivel 3: Mixto (lineales y cuadráticas)',
        'formula_hint': 'Escribí y(x) = f(x). Ejemplos: 2x+3   o   x^2-4x+2   o   -0.5x^2+3',
        'targets': [(-9, -2), (-6, 7), (-2, -5), (0, 8), (1, 4), (4, -6), (7, 5), (9, -1)],
        'tolerance': 0.35,
    },
]
